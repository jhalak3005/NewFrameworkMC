package com.cucumber.test.search;



/*@RunWith(Cucumber.class)
@CucumberOptions(
		format= {"pretty","json:target/cucumber_apm.json"},
		glue= {"com.cuccumber.steps.search.PortalSearchSteps"},
		feature="src/test/resources/search/portalSearch.feature",
		tags= {"~@Ignore"},
		strict=true,
		snippets=SnipppetType.CAMELCASE
		)*/
public class PortalSearchTest {

}
