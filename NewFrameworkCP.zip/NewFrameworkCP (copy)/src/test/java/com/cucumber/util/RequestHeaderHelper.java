package com.cucumber.util;

import java.util.HashMap;
import java.util.Map;

public class RequestHeaderHelper {
	
	public static Map<String, String> getHeader(){
		Map<String, String> header=new HashMap();
		header.put("q", "DID_ERROR");
		header.put("row", "10");
		header.put("redhat_client", "portal-search");
		header.put("start", "9990");
		header.put("rerank", "true");
		
		return header;
		
	}
	
}
