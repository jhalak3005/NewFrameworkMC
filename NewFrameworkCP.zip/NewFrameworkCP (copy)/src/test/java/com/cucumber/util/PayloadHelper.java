package com.cucumber.util;

import java.util.HashMap;
import java.util.Map;

public class PayloadHelper {
	
	public static Map<String, String> getDefaultPortalSearchPayLoad(){
		Map<String, String> requestPayload=new HashMap();
		requestPayload.put("summary", "How to activate a Satellite Certificate for a Red Hat Satellite 5 Server?");
		requestPayload.put("description", "configuration issue");
		requestPayload.put("product", "Red Hat Satellite or Proxy");
		requestPayload.put("version", "6.2");
		
		return requestPayload;
		
	}

}
