package com.cucumber.util;

import java.util.Map;
import java.util.logging.Logger;

public final class RestRequestDetails {
	
	private Map<String, String> headers=null;
	private String merchant;
	private String password;
	private Map<String, String> json;

	
	public RestRequestDetails(String merchant, String password) {
		this.merchant=merchant;
		this.password=password;
	}
	
	public RestRequestDetails withHeaders(Map<String, String> headers) {
		this.headers=headers;
		return this;
	}
	
	public RestRequestDetails withJson(Map<String, String> json) {
		this.json=json;
		return this;
	}
	
	public static String doApiPostRequest(String apiOperation, RestRequestDetails details) {
		//String urlVersion=version!=null ? getVersion():getOtherVersion();
		String url="https://access.stage.redhat.com/rs";
		
		
		return null;
		
	}
}
