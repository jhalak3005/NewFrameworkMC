package com.cucumber.util;

public enum ApiSearchOperation {

	PORTAL_SEARCH,
	PCM_SEARCH,
	ASCENSION_SEARCH,
	CONTAINER_SEARCH;
	
	
	public String getValue() {
		return name();
		
	}
}
