package com.cucumber.steps.search;

import com.cucumber.context.CucumberTestContext;

public class AscensionSearchSteps {

	private final CucumberTestContext cucumberTestContext;
	
	public AscensionSearchSteps(CucumberTestContext cucumberTestContext) {
		this.cucumberTestContext=cucumberTestContext;
	}
	
}
