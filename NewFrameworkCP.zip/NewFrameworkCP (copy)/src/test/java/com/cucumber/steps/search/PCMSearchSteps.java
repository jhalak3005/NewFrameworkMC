package com.cucumber.steps.search;

import com.cucumber.context.CucumberTestContext;

public class PCMSearchSteps {
	
	CucumberTestContext cucumberTestContext;
	
	public PCMSearchSteps(CucumberTestContext cucumberTestContext) {
		this.cucumberTestContext=cucumberTestContext;
	}

}
