package com.cucumber.steps.search;

import java.util.Map;

import com.cucumber.context.CucumberTestContext;
import com.cucumber.util.ApiSearchOperation;
import com.cucumber.util.PayloadHelper;
import com.cucumber.util.RequestHeaderHelper;
import com.cucumber.util.RestRequestDetails;

public class PortalSearchSteps {
	
	private final CucumberTestContext cucumberTestContext;
	
 public PortalSearchSteps(CucumberTestContext cucumberTestContext) {
	 this.cucumberTestContext=cucumberTestContext;
	 this.cucumberTestContext.getStepDefs().setPortalSearchSteps(this);
 }
 
 @Given("user searches a caseId on portalSearch")
 public void userSearchesACaseIdOnPortalSearch() {
     doPortalSearchrequest();
 }
 
 @Then("gets a valid response")
 public void getsAValidResponse() {
     String response=cucumberTestContext.getSearchDetail().getPortalSearchResponse();
     
 }
 
 private void doPortalSearchrequest() {
	 RestRequestDetails details=createPortalSearchRequest();
	 String response=postSearchRequest(details);
	 cucumberTestContext.getSearchDetail().setPortalSearchResponse(response);
	 //Do assertions on response
	 
	 	
 }
 
 private RestRequestDetails createPortalSearchRequest() {
	 Map<String, String> portalSearchRequest=buildPortalSearchRequest();
	 return new RestRequestDetails("", "password").withHeaders(RequestHeaderHelper.getHeader()).withJson(portalSearchRequest);
 }
 
 private Map<String, String> buildPortalSearchRequest(){
	 Map<String, String> portalSearchRequest=PayloadHelper.getDefaultPortalSearchPayLoad();
	 return portalSearchRequest;
 }
 
 private String postSearchRequest(RestRequestDetails details) {
	 return RestRequestDetails.doApiPostRequest(ApiSearchOperation.PORTAL_SEARCH.getValue(),details);
 }
 
 
}
