package com.cucumber.context;

public class SearchDetail {

	//private LiquidBean portalSearchResponse;
	private String portalSearchResponse;
	private String PCMSearchResponse;
	private String ascensionsSearchResponse;
	
	public String getPortalSearchResponse() {
		return portalSearchResponse;
	}

	public void setPortalSearchResponse(String portalSearchResponse) {
		this.portalSearchResponse = portalSearchResponse;
	}

	public String getPCMSearchResponse() {
		return PCMSearchResponse;
	}

	public void setPCMSearchResponse(String pCMSearchResponse) {
		PCMSearchResponse = pCMSearchResponse;
	}

	public String getAscensionsSearchResponse() {
		return ascensionsSearchResponse;
	}

	public void setAscensionsSearchResponse(String ascensionsSearchResponse) {
		this.ascensionsSearchResponse = ascensionsSearchResponse;
	}
	
	public String getSesionId() {
		//portalSearchResponse.getString("");
		return null;
	}
}
