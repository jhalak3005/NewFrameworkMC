package com.cucumber.context;

import com.cucumber.steps.search.AscensionSearchSteps;
import com.cucumber.steps.search.PCMSearchSteps;
import com.cucumber.steps.search.PortalSearchSteps;

//@Data
public final class WtffStepDefinitions {

	private PortalSearchSteps portalSearchSteps;
	
	public PortalSearchSteps getPortalSearchSteps() {
		return portalSearchSteps;
	}
	public void setPortalSearchSteps(PortalSearchSteps portalSearchSteps) {
		this.portalSearchSteps = portalSearchSteps;
	}
	public PCMSearchSteps getPcmSearchSteps() {
		return pcmSearchSteps;
	}
	public void setPcmSearchSteps(PCMSearchSteps pcmSearchSteps) {
		this.pcmSearchSteps = pcmSearchSteps;
	}
	public AscensionSearchSteps getAscensionSearchSteps() {
		return ascensionSearchSteps;
	}
	public void setAscensionSearchSteps(AscensionSearchSteps ascensionSearchSteps) {
		this.ascensionSearchSteps = ascensionSearchSteps;
	}
	private PCMSearchSteps pcmSearchSteps;
	private AscensionSearchSteps ascensionSearchSteps;
}
