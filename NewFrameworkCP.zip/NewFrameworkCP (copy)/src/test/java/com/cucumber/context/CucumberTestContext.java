package com.cucumber.context;

import com.cucumber.steps.search.PortalSearchSteps;

//@Data
public class CucumberTestContext {

	private final WtffStepDefinitions stepDefs=new WtffStepDefinitions();
	private SearchDetail searchDetail;

	public WtffStepDefinitions getStepDefs() {
		return stepDefs;
	}
	
	public SearchDetail getSearchDetail() {
		return searchDetail;
	}

	public void setSearchDetail(SearchDetail searchDetail) {
		this.searchDetail = searchDetail;
	}

	

	
}
